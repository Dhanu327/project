﻿create view CustomerView
as
select FirstName,LastName,Email,Mobile
from Customer