﻿create procedure sp_cust_List
as
begin
select FirstName,LastName,Email,Moblie from Customer
end
exec sp_cust_List