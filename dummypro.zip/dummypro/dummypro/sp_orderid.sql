﻿create procedure sp_GetOrderByOrderId(@Orderid int)
as
begin
select *from Orders where Orderid=@Orderid
end
exec sp_GetOrderByOrderId 1
