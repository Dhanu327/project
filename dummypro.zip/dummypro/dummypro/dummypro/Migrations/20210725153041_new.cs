﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace dummypro.Migrations
{
    public partial class @new : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Payment_Orders_Orderid",
                table: "Payment");

            migrationBuilder.DropIndex(
                name: "IX_Payment_Orderid",
                table: "Payment");

            migrationBuilder.AlterColumn<long>(
                name: "Moblie",
                table: "Customer",
                type: "Bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "Bigint",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "Mobile",
                table: "Admin",
                type: "Bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "Bigint",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_OrderItem_Menuid",
                table: "OrderItem",
                column: "Menuid");

            migrationBuilder.CreateIndex(
                name: "IX_OrderItem_Orderid",
                table: "OrderItem",
                column: "Orderid");

            migrationBuilder.AddForeignKey(
                name: "FK_OrderItem_Menu_Menuid",
                table: "OrderItem",
                column: "Menuid",
                principalTable: "Menu",
                principalColumn: "Menuid",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_OrderItem_Orders_Orderid",
                table: "OrderItem",
                column: "Orderid",
                principalTable: "Orders",
                principalColumn: "Orderid",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OrderItem_Menu_Menuid",
                table: "OrderItem");

            migrationBuilder.DropForeignKey(
                name: "FK_OrderItem_Orders_Orderid",
                table: "OrderItem");

            migrationBuilder.DropIndex(
                name: "IX_OrderItem_Menuid",
                table: "OrderItem");

            migrationBuilder.DropIndex(
                name: "IX_OrderItem_Orderid",
                table: "OrderItem");

            migrationBuilder.AlterColumn<long>(
                name: "Moblie",
                table: "Customer",
                type: "Bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "Bigint");

            migrationBuilder.AlterColumn<long>(
                name: "Mobile",
                table: "Admin",
                type: "Bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "Bigint");

            migrationBuilder.CreateIndex(
                name: "IX_Payment_Orderid",
                table: "Payment",
                column: "Orderid");

            migrationBuilder.AddForeignKey(
                name: "FK_Payment_Orders_Orderid",
                table: "Payment",
                column: "Orderid",
                principalTable: "Orders",
                principalColumn: "Orderid",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
