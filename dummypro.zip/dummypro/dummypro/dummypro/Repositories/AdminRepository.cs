﻿using System.Collections.Generic;
using System.Linq;
using DemoFoodApI.Entities;
<<<<<<< Updated upstream


=======
>>>>>>> Stashed changes
using Microsoft.EntityFrameworkCore;


namespace DemoFoodApI.Repositories
{
    public class AdminRepository : IAdminRepository
    {
        private MyContext context = null;
        public AdminRepository(MyContext context)
        {
            this.context = context;
        }
        public void AddMenuItem(Menu menu)
        {
            context.Add(menu);
            context.SaveChanges();
        }
        public void DeleteMenuItem(int menuid)
        {
            Menu menu = context.Menus.SingleOrDefault(i => i.Menuid == menuid);
            context.Remove(menu);
            context.SaveChanges();
        }
        public Customer GetCustomerByCustomerId(int customerid)
        {
            Customer customer = context.Customers.SingleOrDefault(i => i.Customerid == customerid);
            return customer;
        }
        public List<string> GetCustomers(Customer customer)
        {
            List<string> Cust = new List<string>();
            Cust.Add(customer.FirstName);
            Cust.Add(customer.LastName);
            Cust.Add(customer.Email);
            return Cust;
           
           
        }
        //public Menu GetMenuByMenuId(int menuid)
        //{
        //    Menu menu = context.Menus.SingleOrDefault(i => i.Menuid == menuid);
        //    return menu;
        //}
        public List<Orders> GetOrderByOrderId(int orderid)
        {
           // Orders orders=context.Orders1.
            List<Orders> orders = context.Orders1.FromSqlRaw("sp_GetOrderByOrderId {0}", orderid).ToList();
            return orders;
            
        }
        public OrderItem GetOrderItem(int orderId)
        {
            OrderItem orderItem = context.OrderItems.SingleOrDefault(i => i.Orderid == orderId);
            return orderItem;
        }
       
       
        public void ModifyOrder(Orders orders1)
        {
            context.Orders1.Update(orders1);
            context.SaveChanges();
        }
        public void UpdatePaymentStatus(Payment payment)
        {
            context.Payments.Update(payment);
        }
        public void UpdateMenuItem(Menu menu)
        {
            context.Menus.Update(menu);
            context.SaveChanges();
        }
        public List<Menu> GetMenuItems()
        {
            List<Menu> menu1 = context.Menus.FromSqlRaw("sp_GetMenuItems").ToList();
            return menu1;
        }

       

        public List<Payment> GetPaymentDetails()
        {
            return context.Payments.ToList();
        }

       

        public Payment GetPaymentDetailsByOrderId(int orderid)
        {
            Payment payment = context.Payments.SingleOrDefault(i => i.Orderid == orderid);
            return payment;
        }

        List<Customer> IAdminRepository.GetCustomers()
        {
            return context.Customers.ToList();
        }

        public void AdminDetails(Admin admin)
        {
            context.Add(admin);
            context.SaveChanges();
        }
    }
}
