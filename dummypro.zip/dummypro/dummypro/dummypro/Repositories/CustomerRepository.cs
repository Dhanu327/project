﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoFoodApI.Entities;
using Microsoft.EntityFrameworkCore;


namespace DemoFoodApI.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private MyContext context = null;
        public CustomerRepository(MyContext context)
        {
            this.context = context;
        }

        public void AddCustomer(Customer customer)
        {
            context.Add(customer);
            context.SaveChanges();
        }
        

        public void AddOrderItem(OrderItem orderItem)
        {
            
            context.Add(orderItem);
            context.SaveChanges();
        }

        public void CancelOrderByOrderId(int orderid)
        {
            List<Orders> order = context.Orders1.FromSqlRaw("sp_CancelOrder {0}", orderid).ToList();
            context.SaveChanges();
        }

      /*  public void DeleteCustomerBycustomerid(int customerid)
        {
            Customer customer = context.Customers.SingleOrDefault(i => i.Customerid == customerid);
            context.Remove(customer);
            context.SaveChanges();
        }*/

        public Menu GetMenuItemByMenuName(string menuname)
        {
            Menu menu = context.Menus.SingleOrDefault(i => i.MenuName == menuname);
            return menu;
        }

        public List<Menu> GetMenuItems()
        {
            return context.Menus.ToList();
        }

        public void MakePayment(Payment payment)
        {
            context.Add(payment);
            context.SaveChanges();
        }

        public void ModifyOrder(Orders orders1)
        {
            context.Orders1.Update(orders1);
            context.SaveChanges();
        }

        public void PlaceOrder(Orders orders1)
        {
            context.Add(orders1);
            context.SaveChanges();
        }

        public string TrackOrderStatusByOrderId(int orderid)
        {
            Payment payment = context.Payments.SingleOrDefault(i => i.Orderid == orderid);
            return payment.Status;
        }
    }
}
