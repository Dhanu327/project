﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoFoodApI.Entities;

namespace DemoFoodApI.Repositories
{
    public interface ICustomerRepository
    {
        public void AddCustomer(Customer customer);
       // public void DeleteCustomerBycustomerid(int customerid);
        List<Menu> GetMenuItems();//1
        Menu GetMenuItemByMenuName(string menuname);//2
        public void AddOrderItem(OrderItem orderItem);//3
        public void PlaceOrder(Orders orders1);//6
        public void ModifyOrder(Orders orders1);//7
        public void CancelOrderByOrderId(int orderid);//4
        public string TrackOrderStatusByOrderId(int orderid);//8
        public void MakePayment(Payment payment);//5
       }
}
