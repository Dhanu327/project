﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoFoodApI.Entities;


namespace DemoFoodApI.Repositories
{
    public interface IAdminRepository
    {
       // public void AdminDetails(Admin admin);
        public void AddMenuItem(Menu menu);//1
        public void UpdateMenuItem(Menu menu);//2
        void DeleteMenuItem(int menuid);//3
        List<Menu> GetMenuItems();//Get Menu Details
       // Menu GetMenuByMenuId(int menuid);//5 Get Menu Details By id
        OrderItem GetOrderItem(int orderId);//6(Get by orderid)

        List<Orders> GetOrderByOrderId(int orderid);//7
        void ModifyOrder(Orders orders1);//8
        List<Customer> GetCustomers(Customer customer);//9
        Customer GetCustomerByCustomerId(int customerid);//10
        List<Payment> GetPaymentDetails();//11
        Payment GetPaymentDetailsByOrderId(int orderid);//12
        public void AdminDetails(Admin admin);


    }
}
