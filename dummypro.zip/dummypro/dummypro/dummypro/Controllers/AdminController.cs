﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoFoodApI.Entities;
using DemoFoodApI.Repositories;
using dummypro;


namespace DemoFoodApI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private IAdminRepository _repository;
        public AdminController(IAdminRepository repository)
        {
            _repository=repository;

        }
        
        //Add Menuitem
        [HttpPost]
        [Route("AddMenu")]
        public IActionResult AddMenuItem(Menu menu)
        {
            try
            {
                _repository.AddMenuItem(menu);
                return Ok("Item Added");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Get Customer by Menuid
        /*[HttpGet]
        [Route("GetMenuByMenuId/{menuid}")]
        public IActionResult GetMenuByMenuId(int menuid)
        {
            Menu menu = _repository.GetMenuByMenuId(menuid);
            if(menu!=null)
                {
                return Ok(menu);
            }
            else
            {
                return NotFound("Invalid Menu");
            }
            
        }*/
        //delete menu by Menu id
        [HttpDelete]
        [Route("DeleteMenuByMenuId/{menuid}")]
        public IActionResult DeleteMenuItem(int menuid)
        {
            try
            {
                _repository.DeleteMenuItem(menuid);
                return Ok("Item Deleted");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        //update Menuitem
        [HttpPut]
        [Route("UpdateMenuItem")]
        public IActionResult UpdateMenuItem(Menu menu)
        {
            try
            {
                _repository.UpdateMenuItem(menu);
                return Ok("Item Update");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        //Menu GetMenuitems
        [HttpGet]
        [Route("GetMenuItem")]
        public List<Menu> GetMenuItems()
        {
            return _repository.GetMenuItems();
        }


        // Get Orderitem by orderitemid
        [HttpGet]
        [Route("GetOrderItem/{orderId}")]
        public IActionResult GetOrderItem(int orderId)
        {
            OrderItem orderItem = _repository.GetOrderItem(orderId);
            if(orderItem != null)
            {
                return Ok(orderItem);
            }
            else
            {
                return NotFound("Invalid Orderitem");
            }
        }
        // Get Order by orderid
        [HttpGet]
        [Route("GetOrderByOrderId/{orderid}")]
        public IActionResult GetOrderByOrderId(int orderid)
        {
            List<Orders> orders = _repository.GetOrderByOrderId(orderid);
            if (orders != null)
            {
                return Ok(orders);
            }
            else
            {
                return NotFound("Invalid Order");
            }
       
        }
        //Modify Order
        [HttpPut]
        [Route("ModifyOrder")]
        public IActionResult ModifyOder(Orders orders1)
        {
            try
            {
                _repository.ModifyOrder(orders1);
                return Ok("Order Modified");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        //Menu GetCustomers
        [HttpGet]
        [Route("GetCustomers")]
        public List<Customer> GetCustomers(Customer customer)
        {
            return _repository.GetCustomers(customer);
        }

        // Get Customer by Customerid
        [HttpGet]
        [Route("GetCustomerByCustomerId/{customerid}")]
        public IActionResult GetCustomerByCustomerId(int customerid)
        {
            Customer customer= _repository.GetCustomerByCustomerId(customerid);
            if (customer != null)
            {
                return Ok(customer);
            }
            else
            {
                return NotFound("Invalid Customer");
            }
        }

        // Get Payment by Orderid
        [HttpGet]
        [Route("GetPaymentDetailsByOrderId/{orderid}")]
        public IActionResult GetPaymentDetailsByOrderId(int orderid)
        {
            Payment payment = _repository.GetPaymentDetailsByOrderId(orderid);
            if (payment != null)
            {
                return Ok(payment);
            }
            else
            {
                return NotFound("Invalid Payment");
            }
        }

        //Payments List
        [HttpGet]
        [Route("GetPaymentDetails")]
        public List<Payment> GetPaymentDetails()
        {
            return _repository.GetPaymentDetails();
        }
        //Admin Details
        [HttpPost]
        [Route("AdminDetails")]
        public IActionResult AdminDetails(Admin admin)
        {
            try
            {
                _repository.AdminDetails(admin);
                return Ok("Admin Details Added");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}