﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoFoodApI.Entities;
using DemoFoodApI.Repositories;

namespace DemoFoodApI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {

        private ICustomerRepository _repository;

        public CustomerController(ICustomerRepository repository)
        {

            _repository = repository;
        }

        //Add Orderitem
        [HttpPost]
        [Route("AddOrderitem")]
        public IActionResult AddOrderItem(OrderItem orderItem)
        {
            try
            {
                _repository.AddOrderItem(orderItem);
                return Ok("OrderItem Added");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        //Place Order
        [HttpPost]
        [Route("PlaceOrder")]
        public IActionResult PlaceOrder(Orders orders1)
        {
            try
            {
                _repository.PlaceOrder(orders1);
                return Ok("Order Placed");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        //ModifyOrder
        [HttpPut]
        [Route("ModifyOrder")]
        public IActionResult ModifyOrder(Orders orders1)
        {
            try
            {
                _repository.ModifyOrder(orders1);
                return Ok("Order Modified");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        //Cancel Order by Orderid
        [HttpDelete]
        [Route("CancelOrderByOrderId/{orderid}")]
        public IActionResult CancelOrderByOrderId(int orderid)
        {
            try
            {
                _repository.CancelOrderByOrderId(orderid);
                return Ok("Order Deleted");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        //Get Menuitem By MenuName
        [HttpGet]
        [Route("GetMenuItemByMenuName/{menuname}")]
        public IActionResult GetMenuItemByMenuName(string menuname)
        {
            Menu menu = _repository.GetMenuItemByMenuName(menuname);
            if (menu != null)
            {
                return Ok(menu);
            }
            else
            {
                return NotFound("Invalid Menu");
            }

        }
        //Menu GetMenuitems
        [HttpGet]
        [Route("GetMenuItem")]
        public List<Menu> GetMenuItems()
        {
            return _repository.GetMenuItems();
        }
        // Make Payment By Orderid
        [HttpPost]
        [Route("MakePayment")]
        public IActionResult MakePayment(Payment payment)
        {
            try
            {
                _repository.MakePayment(payment);
                return Ok(payment);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        //TrackOrderStatusByOrderid
        //[HttpGet]
        //[Route("TrackOrderStatusByOrderid/{orderid}")]
        //public string TrackOrderStatusByOrderid(int orderid)
        //{
        //    return _repository.TrackOrderStatusByOrderid(orderid);
        //}
        //Add customer
        [HttpPost]
        [Route("AddCustomer")]
        public IActionResult AddCustomer(Customer customer)
        {
            try
            {
                _repository.AddCustomer(customer);
                return Ok(customer);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /* [HttpDelete]
         [Route("DeleteCustomerBycustomerId/{customerid}")]
         public IActionResult DeleteCustomerBycustomerId(int customerid)
         {
             try
             {
                 _repository.DeleteCustomerByCustomerId(customerid);
                 return Ok("Customer Deleted");
             }
             catch (Exception ex)
             {
                 return BadRequest(ex.Message);
             }

         }*/
    }
}