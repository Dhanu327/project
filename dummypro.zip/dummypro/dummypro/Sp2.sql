﻿create procedure sp_customersList(
@FirstName nvarchar(20),
@LastName  NVARCHAR (20) ,
@Email NVARCHAR (20),
@Mobile BIGINT)
as
begin
begin try
select @FirstName=FirstName,@LastName=LastName,@Email=Email,@Mobile=Moblie from Customer
end try
begin catch
print 'Error Occured'
end catch
end
exec sp_customersList