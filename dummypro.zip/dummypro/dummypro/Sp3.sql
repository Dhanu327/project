﻿Create procedure sp_GetMenuItems
as
begin
---Sql statements
select * from Menu
end
go
-- run the procedure
exec sp_GetMenuItems