﻿CREATE USER MaskUser WITHOUT LOGIN; 
GRANT SELECT ON Customer TO MaskUser;
ALTER TABLE Customer 
ALTER COLUMN Password nvarchar(20) MASKED WITH (FUNCTION = 'default()');
EXECUTE AS USER = 'MaskUser'
SELECT * FROM Customer
REVERT
GO