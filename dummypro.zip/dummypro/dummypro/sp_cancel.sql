﻿create procedure sp_CancelOrder(@Orderid int)
as
begin
delete from Orders where Orderid=@Orderi
end
exec sp_CancelOrder 2